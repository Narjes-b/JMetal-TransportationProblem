
//  IntSolutionType.java
//
//  Author:
//       Antonio J. Nebro <antonio@lcc.uma.es>
//       Juan J. Durillo <durillo@lcc.uma.es>
// 
//  Copyright (c) 2011 Antonio J. Nebro, Juan J. Durillo
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
// 
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

package jmetal.encodings.solutionType;

import java.util.ArrayList;

import java.util.Random;

import jmetal.core.Problem;
import jmetal.core.SolutionType;
import jmetal.core.Variable;
import jmetal.encodings.variable.Int;
import jmetal.problems.AdaptiveInterface.Input;
import jmetal.problems.AdaptiveInterface.MySolution;
import jmetal.problems.AdaptiveInterface.Rule;
import jmetal.problems.AdaptiveInterface.Rule1;
import jmetal.problems.AdaptiveInterface.Rule2;
import jmetal.problems.AdaptiveInterface.Rule3;
import jmetal.problems.AdaptiveInterface.Rule4;
import jmetal.problems.AdaptiveInterface.Rule5;
import jmetal.problems.AdaptiveInterface.Rule6;
import jmetal.problems.AdaptiveInterface.rules;
/**
 * Class representing the solution type of solutions composed of Int variables 
 */
public class IntSolutionType extends SolutionType {
static MySolution S = new MySolution ();
	static rules R =new rules();
	public static ArrayList<Rule> rules ; 
	public static ArrayList<Rule1> rules1 = new ArrayList<Rule1> ();
	public static ArrayList<Rule2> rules2 = new ArrayList<Rule2> ();
	public static ArrayList<Rule3> rules3 = new ArrayList<Rule3> ();
	public static  ArrayList<Rule4> rules4 = new ArrayList<Rule4> ();
	public static  ArrayList<Rule5> rules5 = new ArrayList<Rule5> ();
	public static  ArrayList<Rule6> rules6 = new ArrayList<Rule6> ();
	public static ArrayList<Rule> Listrules ;
	public static ArrayList<Rule1> Listrules1 = new ArrayList<Rule1> ();
	public static ArrayList<Rule2> Listrules2 = new ArrayList<Rule2> ();
	public static ArrayList<Rule3> Listrules3 = new ArrayList<Rule3> ();
	public static  ArrayList<Rule4> Listrules4 = new ArrayList<Rule4> ();
	public static  ArrayList<Rule5> Listrules5 = new ArrayList<Rule5> ();
	public static  ArrayList<Rule6> Listrules6 = new ArrayList<Rule6> ();
	//= new ArrayList<Rule> ();
	 static Input input = new Input ();
	 public static int min_rules_size = 10 ;
	 public static int max_rules_size =20;
	 public static int rules_size ;
	 int h =0;

	/**
	 * Constructor
	 * @param problem  Problem to solve
	 */
	public IntSolutionType(Problem problem) {
		super(problem) ;
	} // Constructor

	/**
	 * Creates the variables of the solution
	 */
	public Variable[] createVariables() {
		Variable[] variables = new Variable[problem_.getNumberOfVariables()];
		rules = new ArrayList<Rule> ();
		Listrules = new ArrayList<Rule> ();
		Random number_generator = new Random();
		///rules_size = min_rules_size+ (int) (Math.random() * ((max_rules_size - min_rules_size) + 1));
  rules_size = number_generator.nextInt(max_rules_size - min_rules_size);
		 if (rules_size < min_rules_size)
			 rules_size = min_rules_size;
        System.out.println("\n number of rules to create : "+rules_size);
		//for (int var = 0; var < problem_.getNumberOfVariables(); var++)
         
		  System.out.println("********** Solution X************ "  );
		  // for (int var = 0; var <rules_size; var++)
			{//variables[var] = new Int((int)problem_.getLowerLimit(var),(int)problem_.getUpperLimit(var)); 
			        rules.addAll(S.create_rules(input,rules_size));
			        rules1.addAll(S.create_rules2(input,rules_size));
			        rules2.addAll(S.create_rules3(input,rules_size));
			        rules3.addAll(S.create_rules4(input,rules_size));
			        rules4.addAll(S.create_rules5(input,rules_size));
			        rules5.addAll(S.create_rules6(input,rules_size));
			        for (int var = 0; var <rules_size; var++)
		    	{Listrules.add(var, rules.get(var));
		    	Listrules1.add(var, rules1.get(var));
		    	Listrules2.add(var, rules2.get(var));
		    	Listrules3.add(var, rules3.get(var));
		    	Listrules4.add(var, rules4.get(var));
		    	Listrules5.add(var, rules5.get(var));
		 }
		  
		    

		return variables ;
	} // createVariables
	}} // IntSolutionType
