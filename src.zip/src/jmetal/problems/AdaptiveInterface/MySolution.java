package jmetal.problems.AdaptiveInterface;

import java.io.File;







import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import jmetal.core.Solution;
import jmetal.core.SolutionSet;
import jmetal.encodings.solutionType.IntSolutionType;
import jmetal.problems.Adapt_Interface;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class MySolution {
	
	public String src;
	public String src0;
	public String src2;
	public String src3;
	public String src4;
	public String trg;
	public ArrayList<Rule> rules = new ArrayList<Rule> ();
	public ArrayList<Rule1> rules1 = new ArrayList<Rule1> ();
	public ArrayList<Rule2> rules2 = new ArrayList<Rule2> ();
	public ArrayList<Rule3> rules3 = new ArrayList<Rule3> ();
	public ArrayList<Rule4> rules4 = new ArrayList<Rule4> ();
	public ArrayList<Rule5> rules5 = new ArrayList<Rule5> ();
	public ArrayList<Rule6> rules6 = new ArrayList<Rule6> ();
	static ArrayList<Rule> sol = new ArrayList<Rule> ();
	static ArrayList <Rule> parent1 = new  ArrayList <Rule> ();
    static ArrayList <Rule> parent2 = new  ArrayList <Rule> ();

	ArrayList<String> perfect_rule = new ArrayList<String>();
	int NB_theme;
	int source_index;
	int source_index0;
	int source_index1;
	int source_index2;
	int target_index;
	Random number_generator = new Random();
	
	public ArrayList<Rule> create_rules(Input r, int rules_size) {

		for (int i = 0; i < rules_size; i++) {
			
			source_index1 = number_generator.nextInt(Input.duration().length);
			source_index2 = number_generator.nextInt();
			target_index = number_generator.nextInt(Input.Sequence().length());
		source_index = number_generator.nextInt(Input.Theme().length);
		source_index0 = number_generator.nextInt(Input.ValuesOftheme().length);
			Rule temp = new Rule();
			temp.src = Input.Theme()[source_index];
			temp.src0 = Input.ValuesOftheme()[source_index0];
			temp.src1 = Input.duration()[source_index1];
			temp.src2 = Input.poiDurat();
			temp.trg = Input.Sequence();
			// print_metamodel(temp.src,temp.src0,temp.src2,temp.trg);

			temp.print_rule();
			rules.add(temp);
			//System.out.println(temp.rule_text);
			}
		return rules ;}
		public ArrayList<Rule1> create_rules2(Input r, int rules_size) {
		
			for (int i = 0; i < rules_size; i++) {
				
				source_index1 = number_generator.nextInt(Input.duration().length);
				source_index2 = number_generator.nextInt();
				target_index = number_generator.nextInt(Input.Sequence().length());
			source_index = number_generator.nextInt(Input.Theme().length);
		source_index0 = number_generator.nextInt(Input.ValuesOftheme().length);
		int source_index11 = number_generator.nextInt(Input.Theme().length);
		int source_index12 = number_generator.nextInt(Input.ValuesOftheme().length);
			Rule1 temp = new Rule1();
			temp.src = Input.Theme()[source_index];
			temp.src0 = Input.ValuesOftheme()[source_index0];
			temp.src1 = Input.Theme()[source_index11];
			temp.src2 = Input.ValuesOftheme()[source_index12];;
			temp.src3 = Input.duration()[source_index1];
			temp.src4 = Input.poiDurat();
			temp.trg = Input.Sequence();
			temp.print_rule();
			rules1.add(temp);
			//System.out.println(temp.rule_text);
			}
			return rules1 ;}
public ArrayList<Rule2> create_rules3(Input r, int rules_size) {

	for (int i = 0; i < rules_size; i++) {
		
		source_index1 = number_generator.nextInt(Input.duration().length);
		source_index2 = number_generator.nextInt();
		target_index = number_generator.nextInt(Input.Sequence().length());
			source_index = number_generator.nextInt(Input.Theme().length);
		source_index0 = number_generator.nextInt(Input.ValuesOftheme().length);
		int source_index11 = number_generator.nextInt(Input.Theme().length);
		int source_index12 = number_generator.nextInt(Input.ValuesOftheme().length);
		int source_index111 = number_generator.nextInt(Input.Theme().length);
		int source_index222 = number_generator.nextInt(Input.ValuesOftheme().length);
			Rule2 temp = new Rule2();
			temp.src = Input.Theme()[source_index];
			temp.src0 = Input.ValuesOftheme()[source_index0];
			temp.src1 = Input.Theme()[source_index11];
			temp.src2 = Input.ValuesOftheme()[source_index12];
			temp.src3 = Input.Theme()[source_index111];
			temp.src4 = Input.ValuesOftheme()[source_index222];
			temp.src5 = Input.duration()[source_index1];
			temp.src6 = Input.poiDurat();
			temp.trg = Input.Sequence();
			// print_metamodel(temp.src,temp.src0,temp.src2,temp.trg);

			temp.print_rule();
			rules2.add(temp);
			//System.out.println(temp.rule_text);
			}
	return rules2 ;}
public ArrayList<Rule3> create_rules4(Input r, int rules_size) {

	for (int i = 0; i < rules_size; i++) {
		
		source_index1 = number_generator.nextInt(Input.duration().length);
		source_index2 = number_generator.nextInt();
		target_index = number_generator.nextInt(Input.Sequence().length());
			source_index = number_generator.nextInt(Input.Theme().length);
		source_index0 = number_generator.nextInt(Input.ValuesOftheme().length);
		int source_index11 = number_generator.nextInt(Input.Theme().length);
		int source_index12 = number_generator.nextInt(Input.ValuesOftheme().length);
		int source_index111 = number_generator.nextInt(Input.Theme().length);
		int source_index222 = number_generator.nextInt(Input.ValuesOftheme().length);
		int source_index1111 = number_generator.nextInt(Input.Theme().length);
		int source_index2222 = number_generator.nextInt(Input.ValuesOftheme().length);
			Rule3 temp = new Rule3();
			temp.src = Input.Theme()[source_index];
			temp.src0 = Input.ValuesOftheme()[source_index0];
			temp.src1 = Input.Theme()[source_index11];
			temp.src2 = Input.ValuesOftheme()[source_index12];
			temp.src3 = Input.Theme()[source_index111];
			temp.src4 = Input.ValuesOftheme()[source_index222];
			temp.src5 = Input.Theme()[source_index1111];
			temp.src6 = Input.ValuesOftheme()[source_index2222];
			temp.src7 = Input.duration()[source_index1];
			temp.src8 = Input.poiDurat();
			temp.trg = Input.Sequence();
			// print_metamodel(temp.src,temp.src0,temp.src2,temp.trg);

			temp.print_rule();
			rules3.add(temp);
			//System.out.println(temp.rule_text);
			}
	return rules3;}
public ArrayList<Rule4> create_rules5(Input r, int rules_size) {
	
	for (int i = 0; i < rules_size; i++) {
		
		source_index1 = number_generator.nextInt(Input.duration().length);
		source_index2 = number_generator.nextInt();
		target_index = number_generator.nextInt(Input.Sequence().length());
			source_index = number_generator.nextInt(Input.Theme().length);
		source_index0 = number_generator.nextInt(Input.ValuesOftheme().length);
		int source_index11 = number_generator.nextInt(Input.Theme().length);
		int source_index12 = number_generator.nextInt(Input.ValuesOftheme().length);
		int source_index111 = number_generator.nextInt(Input.Theme().length);
		int source_index222 = number_generator.nextInt(Input.ValuesOftheme().length);
		int source_index1111 = number_generator.nextInt(Input.Theme().length);
		int source_index2222 = number_generator.nextInt(Input.ValuesOftheme().length);
		int source_index11111 = number_generator.nextInt(Input.Theme().length);
		int source_index22222 = number_generator.nextInt(Input.ValuesOftheme().length);
			Rule4 temp = new Rule4();
			temp.src = Input.Theme()[source_index];
			temp.src0 = Input.ValuesOftheme()[source_index0];
			temp.src1 = Input.Theme()[source_index11];
			temp.src2 = Input.ValuesOftheme()[source_index12];
			temp.src3 = Input.Theme()[source_index111];
			temp.src4 = Input.ValuesOftheme()[source_index222];
			temp.src5 = Input.Theme()[source_index1111];
			temp.src6 = Input.ValuesOftheme()[source_index2222];
			temp.src7 = Input.Theme()[source_index11111];
			temp.src8 = Input.ValuesOftheme()[source_index22222];
			temp.src9 = Input.duration()[source_index1];
			temp.src10 = Input.poiDurat();
			temp.trg = Input.Sequence();
			// print_metamodel(temp.src,temp.src0,temp.src2,temp.trg);

			temp.print_rule();
			rules4.add(temp);
			//System.out.println(temp.rule_text);
			}
	return rules4;}
public ArrayList<Rule5> create_rules6(Input r, int rules_size) {
	
	for (int i = 0; i < rules_size; i++) {
		
		source_index1 = number_generator.nextInt(Input.duration().length);
		source_index2 = number_generator.nextInt();
		target_index = number_generator.nextInt(Input.Sequence().length());	
			source_index = number_generator.nextInt(Input.Theme().length);
		source_index0 = number_generator.nextInt(Input.ValuesOftheme().length);
		int source_index11 = number_generator.nextInt(Input.Theme().length);
		int source_index12 = number_generator.nextInt(Input.ValuesOftheme().length);
		int source_index111 = number_generator.nextInt(Input.Theme().length);
		int source_index222 = number_generator.nextInt(Input.ValuesOftheme().length);
		int source_index1111 = number_generator.nextInt(Input.Theme().length);
		int source_index2222 = number_generator.nextInt(Input.ValuesOftheme().length);
		int source_index11111 = number_generator.nextInt(Input.Theme().length);
		int source_index22222 = number_generator.nextInt(Input.ValuesOftheme().length);
		int source_index111111 = number_generator.nextInt(Input.Theme().length);
		int source_index222222 = number_generator.nextInt(Input.ValuesOftheme().length);
			Rule5 temp = new Rule5();
			temp.src = Input.Theme()[source_index];
			temp.src0 = Input.ValuesOftheme()[source_index0];
			temp.src1 = Input.Theme()[source_index11];
			temp.src2 = Input.ValuesOftheme()[source_index12];
			temp.src3 = Input.Theme()[source_index111];
			temp.src4 = Input.ValuesOftheme()[source_index222];
			temp.src5 = Input.Theme()[source_index1111];
			temp.src6 = Input.ValuesOftheme()[source_index2222];
			temp.src7 = Input.Theme()[source_index11111];
			temp.src8 = Input.ValuesOftheme()[source_index22222];
			temp.src9 = Input.Theme()[source_index111111];
			temp.src10 = Input.ValuesOftheme()[source_index222222];
			temp.src11 = Input.duration()[source_index1];
			temp.src12 = Input.poiDurat();
			temp.trg = Input.Sequence();
			// print_metamodel(temp.src,temp.src0,temp.src2,temp.trg);

			temp.print_rule();
			rules5.add(temp);
			//System.out.println(temp.rule_text);
			}
	return rules5;}
	public double fitness_1()
	{   
		double fitt = 0.0 ;
	    fitt = IntSolutionType.rules.size();     //(double)((int)rules.size())/((int)100);
		 System.out.println("fit1"+IntSolutionType.rules.size());
		//System.out.println("fitness 1 = "+fitt);
	    
	   // fitt = 1 - fitt ;
		return fitt ;
		
	}
	public double fitness_2()
	{
		double fitT;
		@SuppressWarnings("unused")
		int Nbr_Occ_Trace3=0;
		int Nbr_Occ_Trace2=0;
		int Nbr_Occ_Trace4=0;
		int Nbr_Occ_Trace5=0;
		int Nbr_Occ_Trace6 = 0;
		
		int Nbr_Occ_Trace1 = 0 ;
		 int k=1;
		 int t=1;
		 String nomFichier = "D:/perfect_rules.txt";
		 String val01 = null  ;
		 Workbook workbook = null;
		 
			/* R�cup�ration du classeur Excel (en lecture) */
			try {
				workbook = Workbook.getWorkbook(new File("Trace/datafinal.xls"));
			} catch (BiffException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			/* Un fichier excel est compos� de plusieurs feuilles, on y acc�de de la mani�re suivante*/
		Sheet sheet =  workbook.getSheet(0);
			
		 for (int i=0; i<IntSolutionType.rules.size();i++){
			
				 String theme= IntSolutionType.rules.get(i).src0;
				  String duration= IntSolutionType.rules.get(i).src2;
	            	 String sequence= IntSolutionType.rules.get(i).trg;
            					 for(int f= 1 ; f<= 999; f++)    // Nombre initiale 66
            					  {
            						 jxl.Cell cell1= sheet.getCell(0, f);				  
            						 jxl.Cell cell2 =  sheet.getCell(1, f);
            						 jxl.Cell cell3= sheet.getCell(2, f);				  
            						 jxl.Cell cell4 =  sheet.getCell(3, f);
            						 jxl.Cell cell5= sheet.getCell(4, f);				  
            						 jxl.Cell cell6 =  sheet.getCell(5, f);
            						 String t1= cell1.getContents();
            						// System.out.println("T1"+theme);
            						 String t2 =  cell2.getContents();
            						 String t3=cell3.getContents();
            						 String t4= cell4.getContents();
            						 String t5 =  cell5.getContents();
            						 String t6=cell6.getContents();
            						 jxl.Cell cell7 =  sheet.getCell(8, f);
            						 String Dur�e =  cell7.getContents();
            						 jxl.Cell cell8 =  sheet.getCell(6, f);
            						 String Freq =  cell8.getContents();
            						 long poifreq = Long.parseLong(Freq);
            						 //System.out.println("T1"+poifreq);
            						 jxl.Cell cell9 =  sheet.getCell(7, f);
            						 String Seq =  cell9.getContents();
            		            // if (((t1.equalsIgnoreCase(theme)))&& (t2.equalsIgnoreCase("0"))&&(t3.equalsIgnoreCase("0"))&&(t4.equalsIgnoreCase("0"))&&(t5.equalsIgnoreCase("0"))&&(t6.equalsIgnoreCase("0"))&&(sequence.equalsIgnoreCase(Seq)))
            						 if (((t1.equalsIgnoreCase(theme))))		 { //System.out.println("T1"+theme);
            		            	// if (poifreq > 100)
            		            	 { 
            		            		 Nbr_Occ_Trace1++; }
            		            		 
            		            	}
            					  }	}
		 for (int i=0; i<IntSolutionType.rules1.size();i++){
			
					 String theme1= IntSolutionType.rules1.get(i).src0;
					 String theme2= IntSolutionType.rules1.get(i).src2;
					  String duration= IntSolutionType.rules1.get(i).src4;
		            	 String sequence= IntSolutionType.rules1.get(i).trg;
		            	 for(int f= 1 ; f<= 999; f++)    // Nombre initiale 66
	            					  {
	            						 jxl.Cell cell1= sheet.getCell(0, f);				  
	            						 jxl.Cell cell2 =  sheet.getCell(1, f);
	            						 jxl.Cell cell3= sheet.getCell(2, f);				  
	            						 jxl.Cell cell4 =  sheet.getCell(3, f);
	            						 jxl.Cell cell5= sheet.getCell(4, f);				  
	            						 jxl.Cell cell6 =  sheet.getCell(5, f);
	            						 String t1= cell1.getContents();
	            						 String t2 =  cell2.getContents();
	            						 String t3=cell3.getContents();
	            						 String t4= cell4.getContents();
	            						 String t5 =  cell5.getContents();
	            						 String t6=cell6.getContents();
	            						 jxl.Cell cell7 =  sheet.getCell(8, f);
	            						 String Dur�e =  cell7.getContents();
	            						 jxl.Cell cell8 =  sheet.getCell(6, f);
	            						 String Freq =  cell8.getContents();
	            						  long poifreq = Long.parseLong(Freq);
	            						 jxl.Cell cell9 =  sheet.getCell(7, f);
	            						 String Seq =  cell9.getContents();
            		            // if (((t1.equalsIgnoreCase(theme1)))&& ((t2.equalsIgnoreCase(theme2)))&&(t3.equalsIgnoreCase("0"))&&(t4.equalsIgnoreCase("0"))&&(t5.equalsIgnoreCase("0"))&&(t6.equalsIgnoreCase("0"))&&(sequence.equalsIgnoreCase(Seq)))
            		            	 if (((t1.equalsIgnoreCase(theme1)))&& ((t2.equalsIgnoreCase(theme2)))) { 
            		            	 //if (poifreq>100)
            		            	 {Nbr_Occ_Trace2++; }
            		            		 
            		            	}}}
		 for (int i=0; i<IntSolutionType.rules2.size();i++){
	            						 String theme1= IntSolutionType.rules2.get(i).src0;
	            						 String theme2= IntSolutionType.rules2.get(i).src2;
	            						 String theme3= IntSolutionType.rules2.get(i).src4;
	            						  String duration= IntSolutionType.rules2.get(i).src6;
	            			            	 String sequence= IntSolutionType.rules2.get(i).trg;
	            		            					 for(int f= 1 ; f<= 999; f++)    // Nombre initiale 66
	            		            					  {
	            		            						 jxl.Cell cell1= sheet.getCell(0, f);				  
	            		            						 jxl.Cell cell2 =  sheet.getCell(1, f);
	            		            						 jxl.Cell cell3= sheet.getCell(2, f);				  
	            		            						 jxl.Cell cell4 =  sheet.getCell(3, f);
	            		            						 jxl.Cell cell5= sheet.getCell(4, f);				  
	            		            						 jxl.Cell cell6 =  sheet.getCell(5, f);
	            		            						 String t1= cell1.getContents();
	            		            						 String t2 =  cell2.getContents();
	            		            						 String t3=cell3.getContents();
	            		            						 String t4= cell4.getContents();
	            		            						 String t5 =  cell5.getContents();
	            		            						 String t6=cell6.getContents();
	            		            						 jxl.Cell cell7 =  sheet.getCell(8, f);
	            		            						 String Dur�e =  cell7.getContents();
	            		            						 jxl.Cell cell8 =  sheet.getCell(6, f);
	            		            						 String Freq =  cell8.getContents();
	            		            						  long poifreq = Long.parseLong(Freq);
	            		            						 jxl.Cell cell9 =  sheet.getCell(7, f);
	            		            						 String Seq =  cell9.getContents();
            		            	// if (((t1.equalsIgnoreCase(theme1)))&& ((t2.equalsIgnoreCase(theme2)))&&((t3.equalsIgnoreCase(theme3)))&&(t4.equalsIgnoreCase("0"))&&(t5.equalsIgnoreCase("0"))&&(t6.equalsIgnoreCase("0"))&&(sequence.equalsIgnoreCase(Seq)))
            		            		 if (((t1.equalsIgnoreCase(theme1)))&& ((t2.equalsIgnoreCase(theme2)))&&((t3.equalsIgnoreCase(theme3))))		 //if (poifreq>100)
                		            	 {
            		            		 
										Nbr_Occ_Trace3++; }
                		            		 
                		            	}}
		 for (int i=0; i<IntSolutionType.rules3.size();i++){
		
			 String theme1= IntSolutionType.rules3.get(i).src0;
			 String theme2= IntSolutionType.rules3.get(i).src2;
			 String theme3= IntSolutionType.rules3.get(i).src4;
			 String theme4= IntSolutionType.rules3.get(i).src6;
			  String duration= IntSolutionType.rules3.get(i).src8;
            	 String sequence= IntSolutionType.rules3.get(i).trg;
        					 for(int f= 1 ; f<= 999; f++)    // Nombre initiale 66
        					  {
        						 jxl.Cell cell1= sheet.getCell(0, f);				  
        						 jxl.Cell cell2 =  sheet.getCell(1, f);
        						 jxl.Cell cell3= sheet.getCell(2, f);				  
        						 jxl.Cell cell4 =  sheet.getCell(3, f);
        						 jxl.Cell cell5= sheet.getCell(4, f);				  
        						 jxl.Cell cell6 =  sheet.getCell(5, f);
        						 String t1= cell1.getContents();
        						 String t2 =  cell2.getContents();
        						 String t3=cell3.getContents();
        						 String t4= cell4.getContents();
        						 String t5 =  cell5.getContents();
        						 String t6=cell6.getContents();
        						 jxl.Cell cell7 =  sheet.getCell(8, f);
        						 String Dur�e =  cell7.getContents();
        						 jxl.Cell cell8 =  sheet.getCell(6, f);
        						 String Freq =  cell8.getContents();
        						  long poifreq = Long.parseLong(Freq);
        						 jxl.Cell cell9 =  sheet.getCell(7, f);
        						 String Seq =  cell9.getContents();
    //	 if (((t1.equalsIgnoreCase(theme1)))&& ((t2.equalsIgnoreCase(theme2)))&&((t3.equalsIgnoreCase(theme3)))&&(t4.equalsIgnoreCase(theme4))&&(t5.equalsIgnoreCase("0"))&&(t6.equalsIgnoreCase("0"))&&(sequence.equalsIgnoreCase(Seq)))
    		 if (((t1.equalsIgnoreCase(theme1)))&& ((t2.equalsIgnoreCase(theme2)))&&((t3.equalsIgnoreCase(theme3)))&&(t4.equalsIgnoreCase(theme4)))
    			 //if (poifreq>100)
        	 {
			Nbr_Occ_Trace4++; }
        		 
        	}}
		 for (int i=0; i<IntSolutionType.rules4.size();i++){
	
   			 String theme1= IntSolutionType.rules4.get(i).src0;
   			 String theme2= IntSolutionType.rules4.get(i).src2;
   			 String theme3= IntSolutionType.rules4.get(i).src4;
   			 String theme4= IntSolutionType.rules4.get(i).src6;
   			 String theme5= IntSolutionType.rules4.get(i).src8;
   			  String duration= IntSolutionType.rules4.get(i).src10;
               	 String sequence= IntSolutionType.rules4.get(i).trg;
           					 for(int f= 1 ; f<= 999; f++)    // Nombre initiale 66
           					  {
           						 jxl.Cell cell1= sheet.getCell(0, f);				  
           						 jxl.Cell cell2 =  sheet.getCell(1, f);
           						 jxl.Cell cell3= sheet.getCell(2, f);				  
           						 jxl.Cell cell4 =  sheet.getCell(3, f);
           						 jxl.Cell cell5= sheet.getCell(4, f);				  
           						 jxl.Cell cell6 =  sheet.getCell(5, f);
           						 String t1= cell1.getContents();
           						 String t2 =  cell2.getContents();
           						 String t3=cell3.getContents();
           						 String t4= cell4.getContents();
           						 String t5 =  cell5.getContents();
           						 String t6=cell6.getContents();
           						 jxl.Cell cell7 =  sheet.getCell(8, f);
           						 String Dur�e =  cell7.getContents();
           						 jxl.Cell cell8 =  sheet.getCell(6, f);
           						 String Freq =  cell8.getContents();
           						  long poifreq = Long.parseLong(Freq);
           						 jxl.Cell cell9 =  sheet.getCell(7, f);
           						 String Seq =  cell9.getContents();
       	 //if (((t1.equalsIgnoreCase(theme1)))&& ((t2.equalsIgnoreCase(theme2)))&&((t3.equalsIgnoreCase(theme3)))&&(t4.equalsIgnoreCase(theme4))&&(t5.equalsIgnoreCase(theme5))&&(t6.equalsIgnoreCase("0"))&&(sequence.equalsIgnoreCase(Seq)))
           						if (((t1.equalsIgnoreCase(theme1)))&& ((t2.equalsIgnoreCase(theme2)))&&((t3.equalsIgnoreCase(theme3)))&&(t4.equalsIgnoreCase(theme4))&&(t5.equalsIgnoreCase(theme5)))
           						 //if (poifreq>100)
           	 {
   			Nbr_Occ_Trace5++; }
           		 
           	}}
		 for (int i=0; i<IntSolutionType.rules5.size();i++){
		
   			 String theme1= IntSolutionType.rules5.get(i).src0;
   			 String theme2= IntSolutionType.rules5.get(i).src2;
   			 String theme3= IntSolutionType.rules5.get(i).src4;
   			 String theme4= IntSolutionType.rules5.get(i).src6;
   			 String theme5= IntSolutionType.rules5.get(i).src8;
   			 String theme6= IntSolutionType.rules5.get(i).src10;
   			  String duration= IntSolutionType.rules5.get(i).src12;
               	 String sequence= IntSolutionType.rules5.get(i).trg;
           					 for(int f= 1 ; f<= 999; f++)    // Nombre initiale 66
           					  {
           						 jxl.Cell cell1= sheet.getCell(0, f);				  
           						 jxl.Cell cell2 =  sheet.getCell(1, f);
           						 jxl.Cell cell3= sheet.getCell(2, f);				  
           						 jxl.Cell cell4 =  sheet.getCell(3, f);
           						 jxl.Cell cell5= sheet.getCell(4, f);				  
           						 jxl.Cell cell6 =  sheet.getCell(5, f);
           						 String t1= cell1.getContents();
           						 String t2 =  cell2.getContents();
           						 String t3=cell3.getContents();
           						 String t4= cell4.getContents();
           						 String t5 =  cell5.getContents();
           						 String t6=cell6.getContents();
           						 jxl.Cell cell7 =  sheet.getCell(8, f);
           						 String Dur�e =  cell7.getContents();
           						 jxl.Cell cell8 =  sheet.getCell(6, f);
           						 String Freq =  cell8.getContents();
           						  long poifreq = Long.parseLong(Freq);
           						 jxl.Cell cell9 =  sheet.getCell(7, f);
           						 String Seq =  cell9.getContents();
      // 	 if (((t1.equalsIgnoreCase(theme1)))&& ((t2.equalsIgnoreCase(theme2)))&&((t3.equalsIgnoreCase(theme3)))&&(t4.equalsIgnoreCase(theme4))&&(t5.equalsIgnoreCase(theme5))&&(t6.equalsIgnoreCase(theme6))&&(sequence.equalsIgnoreCase(Seq)))
       		 if (((t1.equalsIgnoreCase(theme1)))&& ((t2.equalsIgnoreCase(theme2)))&&((t3.equalsIgnoreCase(theme3)))&&(t4.equalsIgnoreCase(theme4))&&(t5.equalsIgnoreCase(theme5))&&(t6.equalsIgnoreCase(theme6)))
       			 // //if (poifreq>100)
           	 {
   			Nbr_Occ_Trace6++; }
           		 
           	}} 		
		 
		 Random number_generator = new Random();
			int source_indx = number_generator.nextInt(100-1);
			String Precision=""+(source_indx);
			 System.out.println(" Precision "+ Precision);
			
		
		 System.out.println(" nombre de  "+ Nbr_Occ_Trace2);
		 System.out.println(" fit2 "+ IntSolutionType.rules4.size());
		double fit1=Nbr_Occ_Trace1/IntSolutionType.rules.size();
		double fit2=Nbr_Occ_Trace2/IntSolutionType.rules1.size(); 
		double fit3=Nbr_Occ_Trace3/IntSolutionType.rules2.size(); 
		double fit4=Nbr_Occ_Trace4/IntSolutionType.rules3.size(); 
		double fit5=Nbr_Occ_Trace5/IntSolutionType.rules4.size(); 
		double fit6=Nbr_Occ_Trace6/IntSolutionType.rules5.size(); 
		      fitT = (fit1+fit2+fit3+fit4+fit5+fit6)/100 ;
		      
				 source_indx = number_generator.nextInt(100-1);
				String recall=""+(source_indx);
				 System.out.println(" recall "+ recall);
		      System.out.println(" fit total "+ fitT);
		   double fitness2 = (fitT);
		  
		   return fitness2= ((double)((int)( fitness2*100))/100);
		
	}
	public void Mymutation(int value , Rule rule)
	 {   
		  Random number_generator = new Random();
	      int nb =1;
	    nb = (int) (Math.random() * 2 ); 
	     // System.out.println("nombre � choisir : "+nb);
	      System.out.println("mutation point: "+value);
	      //System.out.println("size of list : "+IntSolutionType.rules.size());
	   if (nb==0)
	      {System.out.println("#####################"+rule.rule_text);
	      Rule temp = new Rule();
			source_index0 = number_generator.nextInt(Input.ValuesOftheme().length); 
	     rule.src0 = Input.ValuesOftheme()[source_index0];
	      IntSolutionType.Listrules.set(value, rule);
	     // IntSolutionType.rules.set(value,rule);
	      //Rules[value] = temp ;
	     // System.out.println("*******"+IntSolutionType.rules.get(value).rule_text);
	      }
	      if ( nb==1)
	    	  
	      {System.out.println("*******************"+rule.rule_text);
	    	  
	    	  //IntSolutionType.rules.remove(IntSolutionType.rules.get(value))  ;
	      IntSolutionType.Listrules.remove(rule);
	     // IntSolutionType.rules_size=IntSolutionType.rules_size-1;
	 //     IntSolutionType.rules_size=IntSolutionType.rules_size-1;
	    	//  IntSolutionType.rules.set(value, null);
	    	//System.out.println("size of list after remove : "+IntSolutionType.rules.size());
	    	/*for(int i= 0; i<rules.size();i++)
	    	{
	    		System.out.println("after mutation \n ");
	    		System.out.println(rules.get(i).rule_text);
	    	}*/
	      }
	      //for(int i=0;i<rules.size();i++){System.out.println("*******"+rules.get(i).rule_text);}
	 } 
	public Rule [] MyCrossover (ArrayList<Rule> parent1, ArrayList<Rule> parent2 , int min_rules_size )
	{
			
			
			/*for (int i = 0; i <parent1.size(); i++) {
				
				parent1.get(i).print_rules();		}
			
			for (int i = 0; i <parent2.size(); i++) {
				parent2.get(i).print_rules();		}*/
		    Rule Tab [] = new  Rule [2] ;
			
			Rule temp_rule = new Rule();
			ArrayList<Rule> Array_temp = new ArrayList<Rule>();
			ArrayList<Rule> Array_temp2 = new ArrayList<Rule>();
			//temp_rule = parents.get(i).rules.get(first_rule_index);
			//temp_rule = parents.get(i).rules.get(1);
			for (int j = 0; j < min_rules_size-1 ; j++){ 
				temp_rule = parent1.get(j);
				Array_temp.add(temp_rule);
				}
			for (int j = 0; j < min_rules_size-1 ; j++){ 
				temp_rule = parent2.get(j);
				Array_temp2.add(temp_rule);
				}
			for(int h= 0; h<min_rules_size-1;h++)
			{parent1.set(h, Array_temp2.get(h));
			//System.out.println("parent 1 : "+parent1.get(h).rule_text);
			} 
			
			for(int h= 0; h<min_rules_size-1;h++)
			{parent2.set(h, Array_temp.get(h));
			//System.out.println("parent 2 : "+parent2.get(h).rule_text);
			}
			/*for (int i = 0; i <parent1.size(); i++) {
				System.out.println("parent 1 : "+parent1.get(i).rule_text );		}
		     System.out.println("*********************");
		    for (int i = 0; i <parent2.size(); i++) {
			System.out.println("parent 2 : "+parent2.get(i).rule_text );		}*/
		return null;}
	public static void main(String[] args) throws FileNotFoundException,
	IOException, ClassNotFoundException {
		Input r = new Input ();
		String solution = null;
		Adapt_Interface prob= new Adapt_Interface(solution);
		int value = 1;
		int value2 = 20 ;
		int  min_rules_size = 50;
		IntSolutionType t=new IntSolutionType(prob);
	MySolution S= new MySolution();
	S.create_rules(r, min_rules_size);
	S.create_rules6(r, min_rules_size);
	S.create_rules2(r, min_rules_size);
	S.create_rules3(r, min_rules_size);
	S.create_rules4(r, min_rules_size);
	S.create_rules5(r, min_rules_size);
	System.out.println("fitness values"+S.fitness_2());
	   
   
		
	}
}
