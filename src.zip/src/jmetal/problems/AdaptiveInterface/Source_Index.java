 package jmetal.problems.AdaptiveInterface;


import java.util.Random;

public class Source_Index {
	static Random number_generator = new Random(); 
	public static  int index_context()
	{
		int source_index0 =  number_generator.nextInt(Input.Theme().length);
		return source_index0 ;
	}
	public static int index_ContxtVal()
	{
		 int source_index1=  number_generator.nextInt(Input.ValuesOftheme().length);
		return source_index1 ;
	}
	/*public static int index_Metrics()
	{
		 int source_index2=  number_generator.nextInt(Input.Population().length);
		return source_index2 ;
	}*/
	public static int index_Duration()
	{
		 int source_index2=  number_generator.nextInt(Input.duration().length);
		return source_index2 ;
	}
	public static int index_Sequence()
	{
		 int target_index=  number_generator.nextInt((Input.Sequence().length()));
		return target_index ;
	}
}
