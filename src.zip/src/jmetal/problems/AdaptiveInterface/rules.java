 package jmetal.problems.AdaptiveInterface;

import java.io.File;


import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Random;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;


public class rules {
	public String src;
	public String src0;
	public String src2;
	public String src3;
	public String src4;
	public String trg;
	public ArrayList<Rule> rules = new ArrayList<Rule> ();
	public ArrayList<Rule1> rules1 = new ArrayList<Rule1> ();
	public ArrayList<Rule2> rules2 = new ArrayList<Rule2> ();
	public ArrayList<Rule3> rules3 = new ArrayList<Rule3> ();
	public ArrayList<Rule4> rules4 = new ArrayList<Rule4> ();
	public ArrayList<Rule5> rules5 = new ArrayList<Rule5> ();
	public ArrayList<Rule6> rules6 = new ArrayList<Rule6> ();
	static ArrayList<Rule> sol = new ArrayList<Rule> ();
	static ArrayList <Rule> parent1 = new  ArrayList <Rule> ();
    static ArrayList <Rule> parent2 = new  ArrayList <Rule> ();
	public ArrayList<Integer> ind1 = new ArrayList<Integer>();
	public ArrayList<Integer> ind2 = new ArrayList<Integer>();
	public ArrayList<Integer> ind3 = new ArrayList<Integer>();
	public ArrayList<Integer> ind4 = new ArrayList<Integer>();
	ArrayList<String> perfect_rule = new ArrayList<String>();
	
	public ArrayList<Rule> create_rules2(Input r, int rules_size) {
		
		//int rules_size;
		int NB_theme;
		int source_index;
		int source_index0;
		int source_index1;
		int source_index2;
		int target_index;
		Random number_generator = new Random();
		//rules_size = min_rules_size+ (int) (Math.random() * ((max_rules_size - min_rules_size) + 1));
		// rules_size = number_generator.nextInt(max_rules_size);
		//if (rules_size < min_rules_size) rules_size = min_rules_size;

		// System.out.println("\n number of rules to create : "+rules_size);

		for (int i = 0; i < rules_size; i++) {
			
			source_index1 = number_generator.nextInt(Input.duration().length);
			source_index2 = number_generator.nextInt();
			target_index = number_generator.nextInt(Input.Sequence().length());
			NB_theme = number_generator.nextInt(Input.ValuesOftheme().length);
		if (NB_theme==1)	
			
		{source_index = number_generator.nextInt(Input.Theme().length);
		source_index0 = number_generator.nextInt(Input.ValuesOftheme().length);
			Rule temp = new Rule();
			temp.src = Input.Theme()[source_index];
			temp.src0 = Input.ValuesOftheme()[source_index0];
			temp.src1 = Input.duration()[source_index1];
			temp.src2 = Input.poiDurat();
			temp.trg = Input.Sequence();
			// print_metamodel(temp.src,temp.src0,temp.src2,temp.trg);

			temp.print_rule();
			rules.add(temp);
			System.out.println(temp.rule_text);}
		if (NB_theme==2)	
		{	source_index = number_generator.nextInt(Input.Theme().length);
		source_index0 = number_generator.nextInt(Input.ValuesOftheme().length);
		int source_index11 = number_generator.nextInt(Input.Theme().length);
		int source_index12 = number_generator.nextInt(Input.ValuesOftheme().length);
			Rule1 temp = new Rule1();
			temp.src = Input.Theme()[source_index];
			temp.src0 = Input.ValuesOftheme()[source_index0];
			temp.src1 = Input.Theme()[source_index11];
			temp.src2 = Input.ValuesOftheme()[source_index12];;
			temp.src3 = Input.duration()[source_index1];
			temp.src4 = Input.poiDurat();
			temp.trg = Input.Sequence();
			// print_metamodel(temp.src,temp.src0,temp.src2,temp.trg);

			temp.print_rule();
			rules1.add(temp);
			System.out.println(temp.rule_text);}
		if (NB_theme==3)	
		{	source_index = number_generator.nextInt(Input.Theme().length);
		source_index0 = number_generator.nextInt(Input.ValuesOftheme().length);
		int source_index11 = number_generator.nextInt(Input.Theme().length);
		int source_index12 = number_generator.nextInt(Input.ValuesOftheme().length);
		int source_index111 = number_generator.nextInt(Input.Theme().length);
		int source_index222 = number_generator.nextInt(Input.ValuesOftheme().length);
			Rule2 temp = new Rule2();
			temp.src = Input.Theme()[source_index];
			temp.src0 = Input.ValuesOftheme()[source_index0];
			temp.src1 = Input.Theme()[source_index11];
			temp.src2 = Input.ValuesOftheme()[source_index12];
			temp.src3 = Input.Theme()[source_index111];
			temp.src4 = Input.ValuesOftheme()[source_index222];
			temp.src5 = Input.duration()[source_index1];
			temp.src6 = Input.poiDurat();
			temp.trg = Input.Sequence();
			// print_metamodel(temp.src,temp.src0,temp.src2,temp.trg);

			temp.print_rule();
			rules2.add(temp);
			System.out.println(temp.rule_text);}
		if (NB_theme==4)	
		{	source_index = number_generator.nextInt(Input.Theme().length);
		source_index0 = number_generator.nextInt(Input.ValuesOftheme().length);
		int source_index11 = number_generator.nextInt(Input.Theme().length);
		int source_index12 = number_generator.nextInt(Input.ValuesOftheme().length);
		int source_index111 = number_generator.nextInt(Input.Theme().length);
		int source_index222 = number_generator.nextInt(Input.ValuesOftheme().length);
		int source_index1111 = number_generator.nextInt(Input.Theme().length);
		int source_index2222 = number_generator.nextInt(Input.ValuesOftheme().length);
			Rule3 temp = new Rule3();
			temp.src = Input.Theme()[source_index];
			temp.src0 = Input.ValuesOftheme()[source_index0];
			temp.src1 = Input.Theme()[source_index11];
			temp.src2 = Input.ValuesOftheme()[source_index12];
			temp.src3 = Input.Theme()[source_index111];
			temp.src4 = Input.ValuesOftheme()[source_index222];
			temp.src5 = Input.Theme()[source_index1111];
			temp.src6 = Input.ValuesOftheme()[source_index2222];
			temp.src7 = Input.duration()[source_index1];
			temp.src8 = Input.poiDurat();
			temp.trg = Input.Sequence();
			// print_metamodel(temp.src,temp.src0,temp.src2,temp.trg);

			temp.print_rule();
			rules3.add(temp);
			System.out.println(temp.rule_text);}
		if (NB_theme==5)	
		{	source_index = number_generator.nextInt(Input.Theme().length);
		source_index0 = number_generator.nextInt(Input.ValuesOftheme().length);
		int source_index11 = number_generator.nextInt(Input.Theme().length);
		int source_index12 = number_generator.nextInt(Input.ValuesOftheme().length);
		int source_index111 = number_generator.nextInt(Input.Theme().length);
		int source_index222 = number_generator.nextInt(Input.ValuesOftheme().length);
		int source_index1111 = number_generator.nextInt(Input.Theme().length);
		int source_index2222 = number_generator.nextInt(Input.ValuesOftheme().length);
		int source_index11111 = number_generator.nextInt(Input.Theme().length);
		int source_index22222 = number_generator.nextInt(Input.ValuesOftheme().length);
			Rule4 temp = new Rule4();
			temp.src = Input.Theme()[source_index];
			temp.src0 = Input.ValuesOftheme()[source_index0];
			temp.src1 = Input.Theme()[source_index11];
			temp.src2 = Input.ValuesOftheme()[source_index12];
			temp.src3 = Input.Theme()[source_index111];
			temp.src4 = Input.ValuesOftheme()[source_index222];
			temp.src5 = Input.Theme()[source_index1111];
			temp.src6 = Input.ValuesOftheme()[source_index2222];
			temp.src7 = Input.Theme()[source_index11111];
			temp.src8 = Input.ValuesOftheme()[source_index22222];
			temp.src9 = Input.duration()[source_index1];
			temp.src10 = Input.poiDurat();
			temp.trg = Input.Sequence();
		// print_metamodel(temp.src,temp.src0,temp.src2,temp.trg);

			temp.print_rule();
			rules4.add(temp);
			System.out.println(temp.rule_text);}
		if (NB_theme==6)	
		{	source_index = number_generator.nextInt(Input.Theme().length);
		source_index0 = number_generator.nextInt(Input.ValuesOftheme().length);
		int source_index11 = number_generator.nextInt(Input.Theme().length);
		int source_index12 = number_generator.nextInt(Input.ValuesOftheme().length);
		int source_index111 = number_generator.nextInt(Input.Theme().length);
		int source_index222 = number_generator.nextInt(Input.ValuesOftheme().length);
		int source_index1111 = number_generator.nextInt(Input.Theme().length);
		int source_index2222 = number_generator.nextInt(Input.ValuesOftheme().length);
		int source_index11111 = number_generator.nextInt(Input.Theme().length);
		int source_index22222 = number_generator.nextInt(Input.ValuesOftheme().length);
		int source_index111111 = number_generator.nextInt(Input.Theme().length);
		int source_index222222 = number_generator.nextInt(Input.ValuesOftheme().length);
			Rule5 temp = new Rule5();
			temp.src = Input.Theme()[source_index];
		temp.src0 = Input.ValuesOftheme()[source_index0];
			temp.src1 = Input.Theme()[source_index11];
			temp.src2 = Input.ValuesOftheme()[source_index12];
			temp.src3 = Input.Theme()[source_index111];
			temp.src4 = Input.ValuesOftheme()[source_index222];
			temp.src5 = Input.Theme()[source_index1111];
			temp.src6 = Input.ValuesOftheme()[source_index2222];
			temp.src7 = Input.Theme()[source_index11111];
			temp.src8 = Input.ValuesOftheme()[source_index22222];
			temp.src9 = Input.Theme()[source_index111111];
			temp.src10 = Input.ValuesOftheme()[source_index222222];
			temp.src11 = Input.duration()[source_index1];
			temp.src12 = Input.poiDurat();
			temp.trg = Input.Sequence();
			// print_metamodel(temp.src,temp.src0,temp.src2,temp.trg);

			temp.print_rule();
			rules5.add(temp);
			System.out.println(temp.rule_text);}
		if (NB_theme==7)	
		{	
			source_index = number_generator.nextInt(Input.Theme().length);
			source_index0 = number_generator.nextInt(Input.ValuesOftheme().length);
			int source_index11 = number_generator.nextInt(Input.Theme().length);
			int source_index12 = number_generator.nextInt(Input.ValuesOftheme().length);
			int source_index111 = number_generator.nextInt(Input.Theme().length);
			int source_index222 = number_generator.nextInt(Input.ValuesOftheme().length);
			int source_index1111 = number_generator.nextInt(Input.Theme().length);
			int source_index2222 = number_generator.nextInt(Input.ValuesOftheme().length);
			int source_index11111 = number_generator.nextInt(Input.Theme().length);
			int source_index22222 = number_generator.nextInt(Input.ValuesOftheme().length);
			int source_index111111 = number_generator.nextInt(Input.Theme().length);
			int source_index222222 = number_generator.nextInt(Input.ValuesOftheme().length);
			int source_index1111111 = number_generator.nextInt(Input.Theme().length);
			int source_index2222222 = number_generator.nextInt(Input.ValuesOftheme().length);
			Rule6 temp = new Rule6();
			temp.src = Input.Theme()[source_index];
			temp.src0 = Input.ValuesOftheme()[source_index0];
			temp.src1 = Input.Theme()[source_index11];
			temp.src2 = Input.ValuesOftheme()[source_index12];
			temp.src3 = Input.Theme()[source_index111];
			temp.src4 = Input.ValuesOftheme()[source_index222];
			temp.src5 = Input.Theme()[source_index1111];
			temp.src6 = Input.ValuesOftheme()[source_index2222];
			temp.src7 = Input.Theme()[source_index11111];
			temp.src8 = Input.ValuesOftheme()[source_index22222];
			temp.src9 = Input.Theme()[source_index111111];
			temp.src10 = Input.ValuesOftheme()[source_index222222];
			temp.src11 = Input.Theme()[source_index1111111];
			temp.src12 = Input.ValuesOftheme()[source_index2222222];
			temp.src13 = Input.duration()[source_index1];
			temp.src14 = Input.poiDurat();
			temp.trg = Input.Sequence();
			// print_metamodel(temp.src,temp.src0,temp.src2,temp.trg);

			temp.print_rule();
			rules6.add(temp);
			System.out.println(temp.rule_text);}
		}
		return rules ;
	
	}

	void print_rules() {
		System.out.println("\n Tree decomposition into leaves : ");
		for (int i = 0; i < rules.size(); i++) {
			System.out.println("\n leaf number " + (i + 1) + " : "
					+ rules.get(i).rule_text);
		}
	}

	
	public static void main(String[] args) throws FileNotFoundException,
	IOException {
		Input r = new Input ();
		
	    int min_rules_size = 100;
		int max_rules_size = 200;
		int value = 1;
		rules R = new rules ();
		R.create_rules2(r, min_rules_size);
		sol.addAll(R.create_rules2(r, min_rules_size));


	}
	
}
