 package jmetal.problems.AdaptiveInterface;


/**
 * 
 */


import java.util.Random;
import java.util.Vector;

/**
 * @author User
 *
 */
public class Input {

	/**
	 * @param args
	 * @return 
	 * @return 
	 */
	public static  String[] Theme() {
		String [] Theme= { "theme"};
	
		return Theme;
	}
	public static  String[] ValuesOftheme() {
		String [] Values= { "Cultural","Shopping","Transport","Museum","Park","Historical"};
	
	
		return Values;

	}
 
	public static  String poidfreq() {
		Random number_generator = new Random();
		int source_indx = number_generator.nextInt(800-1);
		String Freq=""+(source_indx);
	
		
		return Freq;
	}
	public static  String[] duration() {
		String [] M= { "duration"};
		return M;
	}
	public static  String poiDurat() {
		Random number_generator = new Random();
		int source_indx = number_generator.nextInt(60-00);
		int source_indx1 = number_generator.nextInt(60-00);
		String  Durat= "00:"+(source_indx)+":"+(source_indx1);
	
		
		return Durat;
	}
	
	public static  String Sequence() {
		Random number_generator = new Random();
		int source_indx = number_generator.nextInt(490-1);
		String Seq= "Class "+source_indx;
		return Seq;

	}
	

}
